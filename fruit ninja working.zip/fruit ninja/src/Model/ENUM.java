package Model;

public enum ENUM {
  APPLE,
  BANANA,
  BASHA,
  BOOM,
  PEACH,
  SANDIA,
  SWORD;
}
