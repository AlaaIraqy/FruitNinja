package Model;

import java.awt.image.BufferedImage;

public class Boom implements GameObject {

	@Override
	public double getXlocation() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double getYlocation() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getMinHeight() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getInitialVelocity() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getFallingVelocity() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Boolean isSliced() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean hasMovedOffScreen() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void slice() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void move(double time) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public BufferedImage[] getBufferedImages() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setXlocation(double xlocation) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setYlocation(double ylocation) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setCutFlag(boolean b) {
		// TODO Auto-generated method stub
		
	}

}
